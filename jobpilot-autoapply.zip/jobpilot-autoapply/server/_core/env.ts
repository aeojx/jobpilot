export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  rapidApiKey: process.env.RAPIDAPI_KEY ?? "",
  sitePassword: process.env.SITE_PASSWORD ?? "",
  resendApiKey: process.env.RESEND_API_KEY ?? "",
  capsolverApiKey: process.env.CAPSOLVER_API_KEY ?? "",
};
